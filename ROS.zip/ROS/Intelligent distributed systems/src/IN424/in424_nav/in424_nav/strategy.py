__author__ = "Arthur Hittinger"

import numpy as np
from collections import deque
import random
import heapq

def get_coarse_explored(exploration, resolution_factor):
    """Returns a coarse grid indicating explored cells."""
    coarse_rows, coarse_cols = exploration.shape[0] // resolution_factor, exploration.shape[1] // resolution_factor
    coarse_explored = np.zeros((coarse_rows, coarse_cols), dtype=bool)
    for r in range(coarse_rows):
        for c in range(coarse_cols):
            if np.any(exploration[r*resolution_factor:(r+1)*resolution_factor, c*resolution_factor:(c+1)*resolution_factor] != 0):
                coarse_explored[r, c] = True
    return coarse_explored

def get_frontier_cells(maze, coarse_explored):
    """Returns the list of frontier cells (unexplored cells adjacent to explored cells)."""
    frontier_cells = []
    rows, cols = coarse_explored.shape
    for r in range(rows):
        for c in range(cols):
            # If cell is unexplored and not a wall
            if not coarse_explored[r, c] and not maze[r, c]:
                # Check if it's adjacent to any explored cell
                for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < rows and 0 <= nc < cols and coarse_explored[nr, nc] and not maze[nr, nc]:
                        frontier_cells.append((r, c))
                        break
    return frontier_cells

def get_unexplored_neighbors(cell, coarse_explored, maze):
    """Count unexplored neighbors of a cell to estimate information gain."""
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]
    rows, cols = coarse_explored.shape
    count = 0
    
    for dr, dc in directions:
        nr, nc = cell[0] + dr, cell[1] + dc
        if (0 <= nr < rows and 0 <= nc < cols and 
            not coarse_explored[nr, nc] and not maze[nr, nc]):
            count += 1
    
    return count

def get_regions(frontier_cells, num_regions=10):
    """Group frontier cells into regions for more efficient multi-robot exploration."""
    if not frontier_cells:
        return []
    
    if len(frontier_cells) <= num_regions:
        return [[cell] for cell in frontier_cells]
        
    # Use K-means clustering to group frontier cells
    regions = [[] for _ in range(num_regions)]
    # Start with random cells as centroids
    centroids = random.sample(frontier_cells, num_regions)
    
    for _ in range(15):  # Increased iterations for better clustering
        # Clear regions
        for region in regions:
            region.clear()
            
        # Assign cells to nearest centroid
        for cell in frontier_cells:
            distances = [np.sqrt((cell[0] - c[0])**2 + (cell[1] - c[1])**2) for c in centroids]
            nearest_region = np.argmin(distances)
            regions[nearest_region].append(cell)
            
        # Update centroids
        for i, region in enumerate(regions):
            if region:
                centroids[i] = (sum(r[0] for r in region) // len(region), 
                                sum(r[1] for r in region) // len(region))
    
    # Handle empty regions
    for i, region in enumerate(regions):
        if not region and frontier_cells:
            regions[i] = [frontier_cells.pop()]
            
    return regions

def calculate_utility(cell, robot_pos, robot_positions, coarse_explored, maze):
    """Calculate utility value for a frontier cell based on information gain and distance."""
    # Information gain (unexplored neighbors)
    unexplored_neighbors = get_unexplored_neighbors(cell, coarse_explored, maze)
    
    # Distance to robot
    distance = abs(cell[0] - robot_pos[0]) + abs(cell[1] - robot_pos[1])
    
    # Distance to other robots (encourage separation)
    min_distance_to_others = float('inf')
    for other_pos in robot_positions:
        if other_pos != robot_pos:
            dist = abs(cell[0] - other_pos[0]) + abs(cell[1] - other_pos[1])
            min_distance_to_others = min(min_distance_to_others, dist)
    
    if min_distance_to_others == float('inf'):
        min_distance_to_others = 0
    
    # Calculate utility: prioritize information gain and separation from other robots
    utility = (unexplored_neighbors * 2) - (0.7 * distance) + (0.3 * min_distance_to_others)
    
    return utility

def a_star_path(maze, start, goal, avoid_positions=None):
    """Returns the shortest path from start to goal using A* algorithm."""
    if start == goal:
        return [start]
    
    if avoid_positions is None:
        avoid_positions = set()
    
    # Manhattan distance heuristic
    def heuristic(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])
    
    # Initialize the open and closed sets
    open_set = []
    closed_set = set()
    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}
    
    # Use heapq (priority queue) for efficient selection of lowest f_score
    heapq.heappush(open_set, (f_score[start], start))
    
    while open_set:
        # Get the node with the lowest f_score
        _, current = heapq.heappop(open_set)
        
        if current == goal:
            # Reconstruct path
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(start)
            path.reverse()
            return path
        
        closed_set.add(current)
        
        # Check neighbors
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            neighbor = (current[0] + dx, current[1] + dy)
            
            # Skip if out of bounds, wall, already visited, or in avoid positions
            if (neighbor[0] < 0 or neighbor[0] >= maze.shape[0] or 
                neighbor[1] < 0 or neighbor[1] >= maze.shape[1] or
                maze[neighbor[0], neighbor[1]] == 1 or
                neighbor in closed_set or
                neighbor in avoid_positions):
                continue
            
            # Calculate g_score for this neighbor
            tentative_g_score = g_score[current] + 1
            
            # If we've found a better path
            if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                # Record path and scores
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g_score
                f_score[neighbor] = tentative_g_score + heuristic(neighbor, goal)
                
                # Add to open set if not already there
                if neighbor not in [node[1] for node in open_set]:
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))
    
    # Try again without avoiding positions if no path found
    if avoid_positions:
        return a_star_path(maze, start, goal)
    
    return None

def calculate_path_cost(path, robot_positions, safety_distance=2):
    """Calculate path cost considering other robots' positions."""
    if not path:
        return float('inf')
        
    cost = len(path)
    
    # Add cost for paths that come close to other robots
    for point in path:
        for robot_pos in robot_positions:
            distance = abs(point[0] - robot_pos[0]) + abs(point[1] - robot_pos[1])
            if distance < safety_distance:
                cost += (safety_distance - distance) * 3  # Increased penalty for proximity
                
    return cost

class RobotController:
    def __init__(self, robots, maze, exploration, resolution_factor):
        """
        Parameters:
          - robots: List of Robot instances.
          - maze: The coarse grid (building plan) for collision detection.
          - exploration: The fine-resolution exploration grid.
          - resolution_factor: Factor to convert coarse coordinates to the fine grid.
        """
        self.robots = robots
        self.maze = maze
        self.exploration = exploration
        self.resolution_factor = resolution_factor
        self.assigned_regions = {}  # Maps robot ID to its assigned region
        self.target_cells = {}      # Maps robot ID to its target cell
        self.move_cooldown = {robot.robot_id: 0 for robot in robots}  # Cooldown timer for robots stuck in place
        self.prev_positions = {robot.robot_id: [] for robot in robots}  # Track previous positions
        self.stuck_counter = {robot.robot_id: 0 for robot in robots}  # Counter for stuck detection
        self.reserved_positions = set()  # Positions reserved by robots
        self.explored_percentage = 0  # Track exploration progress

    def is_robot_stuck(self, robot_id, current_pos):
        """Check if a robot is stuck (oscillating between positions)."""
        positions = self.prev_positions[robot_id]
        positions.append(current_pos)
        
        # Keep only the last 10 positions
        if len(positions) > 10:
            positions.pop(0)
            
        self.prev_positions[robot_id] = positions
        
        # If we don't have enough history, robot is not considered stuck
        if len(positions) < 5:
            return False
            
        # Check if the robot has been oscillating between the same positions
        position_counts = {}
        for pos in positions[-5:]:  # Look at last 5 positions
            position_counts[pos] = position_counts.get(pos, 0) + 1
            
        # Robot is stuck if it's been in the same position multiple times
        return max(position_counts.values()) >= 3

    def update(self):
        """Main update method for robot control."""
        coarse_explored = get_coarse_explored(self.exploration, self.resolution_factor)
        
        # Calculate exploration percentage
        total_cells = np.sum(self.maze == 0)
        explored_cells = np.sum(coarse_explored & (self.maze == 0))
        self.explored_percentage = (explored_cells / total_cells) * 100 if total_cells > 0 else 100
        
        if self.explored_percentage >= 99:
            return
            
        # Get frontier cells and divide into regions
        frontier_cells = get_frontier_cells(self.maze, coarse_explored)
        if not frontier_cells:
            return
            
        # Reset reserved positions
        self.reserved_positions = set()
        
        # Get current positions of all robots
        robot_positions = [robot.coarse_position for robot in self.robots]
        
        # Process each robot's movement
        proposed_moves = {}
        
        # Sort robots by ID (lower ID gets priority)
        for robot in sorted(self.robots, key=lambda r: r.robot_id):
            robot_id = robot.robot_id
            current_pos = robot.coarse_position
            
            # Check if robot is stuck
            if self.is_robot_stuck(robot_id, current_pos):
                self.stuck_counter[robot_id] += 1
                if self.stuck_counter[robot_id] >= 3:  # If stuck for multiple turns
                    # Reset region assignment
                    if robot_id in self.assigned_regions:
                        del self.assigned_regions[robot_id]
                    # Reset stuck counter
                    self.stuck_counter[robot_id] = 0
            else:
                self.stuck_counter[robot_id] = 0
            
            # Check if cooldown is active
            if self.move_cooldown[robot_id] > 0:
                self.move_cooldown[robot_id] -= 1
                proposed_moves[robot] = current_pos  # Stay in place
                continue
                
            # Divide frontiers into regions if needed
            regions = get_regions(frontier_cells, len(self.robots))
                
            # Assign or update region for the robot
            if robot_id not in self.assigned_regions or not self.assigned_regions[robot_id]:
                # Calculate utility for each region
                region_utilities = []
                
                for region in regions:
                    if not region:
                        continue
                        
                    # Check if this region is already assigned to another robot
                    region_assigned = False
                    for r_id, assigned_region in self.assigned_regions.items():
                        if r_id != robot_id and assigned_region and set(assigned_region) == set(region):
                            region_assigned = True
                            break
                            
                    if region_assigned:
                        continue
                        
                    # Calculate average utility for this region
                    avg_utility = sum(calculate_utility(cell, current_pos, robot_positions, 
                                                    coarse_explored, self.maze) for cell in region) / len(region)
                    region_utilities.append((region, avg_utility))
                
                # Select the highest utility region
                if region_utilities:
                    best_region = max(region_utilities, key=lambda x: x[1])[0]
                    self.assigned_regions[robot_id] = best_region
                    if best_region in regions:
                        regions.remove(best_region)
                else:
                    # If no suitable region, try to find any frontier cell
                    if frontier_cells:
                        frontier_utilities = [(cell, calculate_utility(cell, current_pos, robot_positions, 
                                                                     coarse_explored, self.maze)) 
                                              for cell in frontier_cells]
                        best_cell = max(frontier_utilities, key=lambda x: x[1])[0]
                        self.assigned_regions[robot_id] = [best_cell]
            
            # Find best target cell in robot's region
            current_region = self.assigned_regions.get(robot_id, [])
            
            best_target = None
            best_path = None
            best_utility = float('-inf')
            
            other_robot_positions = set(pos for i, pos in enumerate(robot_positions) if i != robot_id - 1)
            
            # Try all cells in the assigned region
            for target in current_region:
                # Calculate utility for this target
                utility = calculate_utility(target, current_pos, robot_positions, coarse_explored, self.maze)
                
                # Find path to target, avoiding other robots' positions
                path = a_star_path(self.maze, current_pos, target, avoid_positions=other_robot_positions)
                
                if path:
                    # Calculate path cost considering other robots
                    path_cost = calculate_path_cost(path, robot_positions)
                    
                    # Adjust utility by path cost
                    adjusted_utility = utility - (0.1 * path_cost)
                    
                    if adjusted_utility > best_utility:
                        best_utility = adjusted_utility
                        best_path = path
                        best_target = target
            
            # If no valid path found in current region, try to find any accessible frontier cell
            if not best_path and frontier_cells:
                # Calculate utility for all frontier cells
                frontier_utilities = []
                for cell in frontier_cells:
                    utility = calculate_utility(cell, current_pos, robot_positions, coarse_explored, self.maze)
                    path = a_star_path(self.maze, current_pos, cell, avoid_positions=other_robot_positions)
                    if path:
                        path_cost = calculate_path_cost(path, robot_positions)
                        adjusted_utility = utility - (0.1 * path_cost)
                        frontier_utilities.append((cell, path, adjusted_utility))
                
                # Sort by utility and try best options
                frontier_utilities.sort(key=lambda x: x[2], reverse=True)
                
                for target, path, utility in frontier_utilities[:min(5, len(frontier_utilities))]:
                    # Check if this cell is already targeted by another robot
                    if any(self.target_cells.get(r.robot_id) == target for r in self.robots if r.robot_id != robot_id):
                        continue
                        
                    best_path = path
                    best_target = target
                    self.assigned_regions[robot_id] = [target]
                    break
            
            # If we found a path, propose the next step
            if best_path and len(best_path) > 1:
                # Reserve the next position
                next_pos = best_path[1]
                self.reserved_positions.add(next_pos)
                
                proposed_moves[robot] = next_pos
                self.target_cells[robot_id] = best_target
            else:
                # Robot can't move, reset its assigned region after a cooldown
                if self.move_cooldown[robot_id] <= 0:
                    self.move_cooldown[robot_id] = 3  # Wait 3 turns before trying a new region
                    if robot_id in self.assigned_regions:
                        del self.assigned_regions[robot_id]
                proposed_moves[robot] = current_pos  # Stay in place
        
        # Execute moves
        for robot, move in proposed_moves.items():
            # Check if another robot is already at the target position
            if not any(other.coarse_position == move for other in self.robots if other != robot):
                robot.coarse_position = move
                
                # If robot reached its target, clear the assigned region
                if self.target_cells.get(robot.robot_id) == move:
                    if robot.robot_id in self.assigned_regions:
                        del self.assigned_regions[robot.robot_id]