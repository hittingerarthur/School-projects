__author__ = "Johvany Gustave, Jonatan Alvarez, Valerian Gregoire--Begranger, Salome Delpierre, Pierre-Henri Engelhard, Arthur Hittinger"
__copyright__ = "Copyright 2025, IN424, IPSA 2025"
__credits__ = ["Johvany Gustave", "Jonatan Alvarez"]
__license__ = "Apache License 2.0"
__version__ = "1.0.0"

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry, OccupancyGrid
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from rclpy.qos import qos_profile_sensor_data
from tf_transformations import euler_from_quaternion
from collections import deque
import random
import heapq

import numpy as np

from .my_common import *

""" TYPES :

    Coordinates:
        x: float
        y: float
        i: int
        j: int
        coordinates are packed in tuples of (x, y)[true coordinates] or (i, j)[grid cells]

    Map:
        UNEXPLORED_SPACE_VALUE: int
        OBSTACLE_VALUE: int
        FREE_SPACE_VALUE: int

    Agents:
        agents_pose: list[tuple[float, float]]
        agents_pose_grid: list[tuple[int, int]]
        destinations: dict[int, tuple[int, int]]

    Lidar:
        ranges: list[float]
        intensities: list[float]
        min_angle: float
        max_angle: float
        step: float
        lidar_range: float

    Regions:
        regions: list[list[tuple[int, int]]]
        path: list[tuple[int, int]]

    Utility:
        azimuth: float
        distance: float
        utility: float
        distance: int
        unexplored_neighbors: int
        min_distance_to_others: float

    A*:
        open_set: list[tuple[float, tuple[int, int]]]
        closed_set: set[tuple[int, int]]
        came_from: dict[tuple[int, int], tuple[int, int]]
        g_score: dict[tuple[int, int], float]
        f_score: dict[tuple[int, int], float]
"""


class Agent(Node):
    """
    This class is used to define the behavior of ONE agent
    """
    dest_regions = dict()
    dest_cells = dict()

    def __init__(self) -> None:
        Node.__init__(self, "Agent")
        
        self.load_params()

        #initialize attributes
        self.agents_pose = [None]*self.nb_agents    #[(x_1, y_1), (x_2, y_2), (x_3, y_3)] if there are 3 agents
        self.agents_pose_grid = [None]*self.nb_agents #[(i_1, j_1), (i_2, j_2), (i_3, j_3)] if there are 3 agents
        self.x = self.y = self.yaw = None   #the pose of this specific agent running the node
        self.row = self.col = self.dest_row = self.dest_col = None # Position of this agent in the gridmap
        self.regions = []
        self.path = []
        self.id = id(self)
        Agent.dest_regions[self.id] = [(0, 0)]
        Agent.dest_cells[self.id] = (0, 0)

        # Lidar variables
        self.ranges = self.intensities = self.min_angle = self.max_angle = self.step = None # Lidar data
        self.lidar_range = 4

        self.map_agent_pub = self.create_publisher(OccupancyGrid, f"/{self.ns}/map", 1) #publisher for agent's own map
        self.init_map()

        # Movement variables
        self.init_movement()

        #Subscribe to agents' pose topic
        odom_methods_cb = [self.odom1_cb, self.odom2_cb, self.odom3_cb]
        for i in range(1, self.nb_agents + 1):
            self.create_subscription(Odometry, f"/bot_{i}/odom", odom_methods_cb[i-1], 1)
        
        if self.nb_agents != 1: #if other agents are involved subscribe to the merged map topic
            self.create_subscription(OccupancyGrid, "/merged_map", self.merged_map_cb, 1)
        
        self.create_subscription(LaserScan, f"{self.ns}/laser/scan", self.lidar_cb, qos_profile=qos_profile_sensor_data) #subscribe to the agent's own LIDAR topic
        self.cmd_vel_pub = self.create_publisher(Twist, f"{self.ns}/cmd_vel", 1)    #publisher to send velocity commands to the robot

        #Create timers to autonomously call the following methods periodically
        self.create_timer(0.2, self.map_update) #0.2s of period <=> 5 Hz
        self.create_timer(0.5, self.strategy)   #0.5s of period <=> 2 Hz
        self.create_timer(1, self.publish_maps) #1Hz

    def load_params(self) -> None:
        """ Load parameters from launch file """
        self.declare_parameters(    #A node has to declare ROS parameters before getting their values from launch files
            namespace="",
            parameters=[
                ("ns", rclpy.Parameter.Type.STRING),    #robot's namespace: either 1, 2 or 3
                ("robot_size", rclpy.Parameter.Type.DOUBLE),    #robot's diameter in meter
                ("env_size", rclpy.Parameter.Type.INTEGER_ARRAY),   #environment dimensions (width height)
                ("nb_agents", rclpy.Parameter.Type.INTEGER),    #total number of agents (this agent included) to map the environment
            ]
        )

        #Get launch file parameters related to this node
        self.ns = self.get_parameter("ns").value
        self.robot_size = self.get_parameter("robot_size").value
        self.env_size = self.get_parameter("env_size").value
        self.nb_agents = self.get_parameter("nb_agents").value

    def init_map(self) -> None:
        """ Initialize the map to share with others if it is bot_1 """
        self.map_msg = OccupancyGrid()
        self.map_msg.header.frame_id = "map"    #set in which reference frame the map will be expressed (DO NOT TOUCH)
        self.map_msg.header.stamp = self.get_clock().now().to_msg() #get the current ROS time to send the msg
        self.map_msg.info.resolution = self.robot_size  #Map cell size corresponds to robot size
        self.map_msg.info.height = int(self.env_size[0]/self.map_msg.info.resolution)   #nb of rows
        self.map_msg.info.width = int(self.env_size[1]/self.map_msg.info.resolution)    #nb of columns
        self.map_msg.info.origin.position.x = -self.env_size[1]/2   #x and y coordinates of the origin in map reference frame
        self.map_msg.info.origin.position.y = -self.env_size[0]/2
        self.map_msg.info.origin.orientation.w = 1.0    #to have a consistent orientation in quaternion: x=0, y=0, z=0, w=1 for no rotation
        self.map = np.ones(shape=(self.map_msg.info.height, self.map_msg.info.width), dtype=np.int8)*UNEXPLORED_SPACE_VALUE #all the cells are unexplored initially
        self.w, self.h = self.map_msg.info.width, self.map_msg.info.height  
    
    def coordinates_to_grid(self, x: float, y: float) -> tuple:
        """
            Computes the indexes (i,j) of the grid cell corresponding to the coordinates
        """
        try:
            # x goes from -10 to 10  from left to right
            # j goes from 0 to 40 from left to right
            j = int(2 * (x + 10))

            # y goes from 10 to -10 from top to bottom
            # i goes from 0 to 40 from top to bottom
            i = int(2 * (10 - y))

            return i, j
        
        except Exception as e:
            self.get_logger().warn(f"Exception in coordinates_to_grid: {e}")
            return None, None

    def grid_to_coordinates(self, i: int, j: int) -> tuple:
        """
            Computes the coordinates (x, y) corresponding to the grid cell indexes (i, j)
        """
        try:
            # Ignore out of grid values
            if i < 0 or j < 0 or i >= self.h or j >= self.w:
                return None, None

            # j goes from 0 to 40 (left to right)
            # x goes from -10 to 10 (left to right)
            x = (j / 2 - 10) + self.map_msg.info.resolution / 2

            # i goes from 0 to 40 (top to bottom)
            # y goes from 10 to -10 (top to bottom)
            y = (10 - i / 2) + self.map_msg.info.resolution / 2

            return x, y

        except Exception as e:
            self.get_logger().warn(f"Exception in grid_to_coordinates: {e}")
            return None, None

    def merged_map_cb(self, msg: Odometry) -> None:
        """ 
            Get the current common map and update ours accordingly.
            This method is automatically called whenever a new message is published on the topic /merged_map.
            'msg' is a nav_msgs/msg/OccupancyGrid message.
        """
        received_map = np.flipud(np.array(msg.data).reshape(self.h, self.w))    #convert the received list into a 2D array and reverse rows
        for i in range(self.h):
            for j in range(self.w):
                if (self.map[i, j] == UNEXPLORED_SPACE_VALUE) and (received_map[i, j] != UNEXPLORED_SPACE_VALUE):
                # if received_map[i, j] != UNEXPLORED_SPACE_VALUE:
                    self.map[i, j] = received_map[i, j]

    def odom1_cb(self, msg: Odometry) -> None:
        """ 
            @brief Get agent 1 position.
            This method is automatically called whenever a new message is published on topic /bot_1/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 1:
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
        self.agents_pose[0] = (x, y)
        self.agents_pose_grid[0] = self.coordinates_to_grid(x, y)
        # self.get_logger().info(f"Agent 1: ({x:.2f}, {y:.2f})")
    
    def odom2_cb(self, msg: Odometry) -> None:
        """ 
            @brief Get agent 2 position.
            This method is automatically called whenever a new message is published on topic /bot_2/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 2:
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
        self.agents_pose[1] = (x, y)
        self.agents_pose_grid[1] = self.coordinates_to_grid(x, y)
        # self.get_logger().info(f"Agent 2: ({x:.2f}, {y:.2f})")

    def odom3_cb(self, msg: Odometry) -> None:
        """ 
            @brief Get agent 3 position.
            This method is automatically called whenever a new message is published on topic /bot_3/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 3:
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
        self.agents_pose[2] = (x, y)
        self.agents_pose_grid[2] = self.coordinates_to_grid(x, y)
        # self.get_logger().info(f"Agent 3: ({x:.2f}, {y:.2f})")

    def compute_point(self, azimuth: float, distance: float, wall=False) -> None:
        """Updates the agent's personnal map based on lidar scan data"""
        try:
            true_azimuth = self.yaw + azimuth
            point_x = self.x + np.cos(true_azimuth) * distance
            point_y = self.y + np.sin(true_azimuth) * distance

            i, j = self.coordinates_to_grid(point_x, point_y)
            if i is None or j is None:
                return

            # Manhattan distance threshold to avoid placing a wall on a robot
            min_distance = self.map_msg.info.resolution * 4

            # Check if too close to any agent
            near_agent = any(abs(i - ai) + abs(j - aj) <= min_distance for ai, aj in self.agents_pose_grid)

            if wall and not near_agent:
                self.map[i, j] = OBSTACLE_VALUE
            else:
                self.map[i, j] = FREE_SPACE_VALUE

        except Exception as e:
            self.get_logger().warn(f"Exception in compute_point: {e}")
            return None, None

    def map_update(self) -> None:
        """Use LIDAR readings to update the occupancy map with free and obstacle points"""
        try:
            angles = np.arange(self.min_angle, self.max_angle + self.step, self.step)

            lidar_scans = 15
            min_range = self.map_msg.info.resolution * 2
            for i, range_ in enumerate(self.ranges):
                azimuth = angles[i]

                # If range is infinite (no hit), simulate to max range
                if range_ == float('inf'):
                    sampled_ranges = np.linspace(0, self.lidar_range * 0.75, lidar_scans)
                else:
                    sampled_ranges = np.linspace(0, range_, lidar_scans, endpoint=False)  # stop before obstacle

                # Mark free space along the ray
                for r in sampled_ranges:
                    self.compute_point(azimuth, r, wall=False)

                # Mark obstacle at the end (if detected)
                if range_ != float('inf') and range_ > min_range:
                    self.compute_point(azimuth, range_, wall=True)

            # Mark robot's own position as free space
            i, j = self.coordinates_to_grid(self.x, self.y)
            if i is not None and j is not None:
                self.map[i, j] = FREE_SPACE_VALUE

        except Exception as e:
            self.get_logger().warn(f"Exception in map_update: {e}")

    def lidar_cb(self, msg: Odometry) -> None:
        """ 
            @brief Get messages from LIDAR topic.
            This method is automatically called whenever a new message is published on topic /bot_x/laser/scan, where 'x' is either 1, 2 or 3.
            
            @param msg This is a sensor_msgs/msg/LaserScan message.
        """
        self.ranges, self.intensities = msg.ranges, msg.intensities
        self.min_angle, self.max_angle, self.step = msg.angle_min, msg.angle_max, msg.angle_increment
        self.map_update()
        # self.get_logger().info(f"Agent {id(self)}: {self.min_angle}")

    def publish_maps(self) -> None:
        """ 
            Publish updated map to topic /bot_x/map, where x is either 1, 2 or 3.
            This method is called periodically (1Hz) by a ROS2 timer, as defined in the constructor of the class.
        """
        self.map_msg.data = np.flipud(self.map).flatten().tolist()  #transform the 2D array into a list to publish it
        self.map_agent_pub.publish(self.map_msg)    #publish map to other agents

    def init_movement(self) -> None:
        self.cmd_vel = Twist()
        self.map_msg.header.stamp = self.get_clock().now().to_msg()

    def move_to_dest(self) -> None:
        try:
            # Convert the target row and column to world coordinates
            dest_x, dest_y = self.grid_to_coordinates(self.dest_row, self.dest_col)

            # Calculate deltas
            delta_x = dest_x - self.x  # x-axis difference
            delta_y = dest_y - self.y  # y-axis difference
            
            # Compute target angle using arctan2 (result is in [-pi, pi])
            # Rows and cols are inverted in the world, so the angle is inverted too
            target_angle = np.arctan2(delta_y, delta_x)
            
            # Convert target_angle to [0, 2π)
            if target_angle < 0:
                target_angle += 2 * np.pi

            # Compute angle difference, ensuring it's within [-π, π]
            angle_diff = (target_angle - self.yaw + np.pi) % (2 * np.pi) - np.pi

            # Tuning parameters
            angle_tolerance = 0.3  # Radians: acceptable angle error
            speed = 0.4            # Linear speed
            rotation_speed = 0.15   # Angular speed

            # Stop if at the destination
            if (self.row, self.col) == (self.dest_row, self.dest_col):
                self.cmd_vel.linear.x = 0.0
                self.cmd_vel.angular.z = 0.0
            
            # Move forward if facing the right direction
            elif abs(angle_diff) < angle_tolerance:
                self.cmd_vel.linear.x = speed
                self.cmd_vel.angular.z = 0.0
            
            # Rotate towards target angle
            else:
                self.cmd_vel.linear.x = 0.0
                self.cmd_vel.angular.z = rotation_speed * np.sign(angle_diff)
        except Exception as e:
            self.get_logger().warn(f"Exception in move_to_dest: {e}")
            return None

    def get_frontier_cells(self) -> list:
        """Returns the list of frontier cells (unexplored cells adjacent to explored cells)."""
        frontier_cells = []

        resolution = self.map_msg.info.resolution
        rows = int(self.env_size[0] / resolution)
        cols = int(self.env_size[1] / resolution)

        for r in range(rows):
            for c in range(cols):
                # Frontier candidates are unexplored cells
                if self.map[r, c] == UNEXPLORED_SPACE_VALUE:
                    # Check 4-connected neighbors for at least one explored (free) cell
                    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        nr, nc = r + dr, c + dc
                        if 0 <= nr < rows and 0 <= nc < cols:
                            if self.map[nr, nc] == FREE_SPACE_VALUE:
                                frontier_cells.append((r, c))
                                # self.map[r, c] = FRONTIER_VALUE
                                break  # No need to check other neighbors
        return frontier_cells

    def get_regions(self, frontier_cells: list, num_regions=10) -> list:
        """Group frontier cells into regions for more efficient multi-robot exploration."""
        if not frontier_cells:
            return []
        
        if len(frontier_cells) <= num_regions:
            return [[cell] for cell in frontier_cells]
            
        # Use K-means clustering to group frontier cells
        regions = [[] for _ in range(num_regions)]
        # Start with random cells as centroids
        centroids = random.sample(frontier_cells, num_regions)
        
        for _ in range(15):  # Increased iterations for better clustering
            # Clear regions
            for region in regions:
                region.clear()
                
            # Assign cells to nearest centroid
            for cell in frontier_cells:
                distances = [np.sqrt((cell[0] - c[0])**2 + (cell[1] - c[1])**2) for c in centroids]
                nearest_region = np.argmin(distances)
                regions[nearest_region].append(cell)
                
            # Update centroids
            for i, region in enumerate(regions):
                if region:
                    centroids[i] = (sum(r[0] for r in region) // len(region), 
                                    sum(r[1] for r in region) // len(region))
        
        # Handle empty regions
        for i, region in enumerate(regions):
            if not region and frontier_cells:
                regions[i] = [frontier_cells.pop()]
                
        return regions.copy()

    def get_unexplored_neighbors(self, cell: tuple) -> int:
        """Count unexplored neighbors of a cell to estimate information gain."""
        # self.env_size
        # self.map_msg.info.resolution
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]
        rows, cols = self.env_size[0], self.env_size[1]
        count = 0
        
        for dr, dc in directions:
            nr, nc = cell[0] + dr, cell[1] + dc
            if (0 <= nr < rows and 0 <= nc < cols and self.map[nr, nc] == UNEXPLORED_SPACE_VALUE):
                count += 1
        
        return count

    def calculate_utility(self, cell: tuple) -> float:
        """Calculate utility value for a frontier cell based on information gain and distance."""
        # Information gain (unexplored neighbors)
        unexplored_neighbors = self.get_unexplored_neighbors(cell)
        
        # Distance to robot
        distance = abs(cell[0] - self.row) + abs(cell[1] - self.col)
        
        # Distance to other robots (encourage separation)
        min_distance_to_others = float('inf')
        for other_pos in self.agents_pose_grid:
            if other_pos != (self.row, self.col):
                dist = abs(cell[0] - other_pos[0]) + abs(cell[1] - other_pos[1])
                min_distance_to_others = min(min_distance_to_others, dist)
        
        if min_distance_to_others == float('inf'):
            min_distance_to_others = 0
        
        # Calculate utility: prioritize information gain and separation from other robots
        utility = round((unexplored_neighbors * 2) - (0.7 * distance) + (0.3 * min_distance_to_others), 3)
        # self.get_logger().info(f"Calculated utility: {utility}")

        return utility

    def center_of_gravity(self, region):
        """
        Computes the center of gravity (centroid) of a region defined by grid coordinates.
        """
        sum_x = sum(cell[0] for cell in region)
        sum_y = sum(cell[1] for cell in region)
        n = len(region)

        x_cog = round(sum_x / n)
        y_cog = round(sum_y / n)

        return (x_cog, y_cog)

    def a_star_path(self, start: tuple, goal: tuple, avoid_positions_flag=False) -> list:
        """Returns the shortest path from start to goal using A* algorithm, without using heapq."""

        if start == goal:
            return [start]

        # Create a set of positions to avoid (e.g. other agents)
        avoid_positions = set()
        if avoid_positions_flag:
            avoid_positions = set(tuple(pos) for pos in self.agents_pose_grid)

        def heuristic(a, b):
            return abs(a[0] - b[0]) + abs(a[1] - b[1])  # Manhattan distance

        open_list = [start]
        came_from = {}
        g_score = {start: 0}
        f_score = {start: heuristic(start, goal)}

        while open_list:
            # Select node with lowest f_score
            current = min(open_list, key=lambda node: f_score.get(node, float('inf')))
            open_list.remove(current)

            if current == goal:
                # Reconstruct path
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                return list(reversed(path))

            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                neighbor = (current[0] + dx, current[1] + dy)

                # Out of bounds
                if not (0 <= neighbor[0] < self.env_size[0] and 0 <= neighbor[1] < self.env_size[1]):
                    continue

                # Wall or avoid
                if self.map[neighbor[0], neighbor[1]] == OBSTACLE_VALUE or neighbor in avoid_positions:
                    continue

                tentative_g = g_score[current] + 1

                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + heuristic(neighbor, goal)

                    if neighbor not in open_list:
                        open_list.append(neighbor)

        # Retry without avoiding positions
        if avoid_positions_flag:
            return self.a_star_path(start, goal, avoid_positions_flag=False)

        return [goal]

    def astar(self, start, goal):
        """
        A* pathfinding algorithm.

        Parameters:
            grid (list[list[int]]): The 2D map.
            start (tuple[int, int]): Starting point (i, j).
            goal (tuple[int, int]): Goal point (i, j).

        Returns:
            list[tuple[int, int]]: Path from start to goal, or empty list if no path.
        """
        DIRECTIONS = [(0, 1), (0, -1), (-1, 0), (1, 0)]
        def in_bounds(pos):
            i, j = pos
            return 0 <= i < self.env_size[0] and 0 <= j < self.env_size[1]

        def is_walkable(pos):
            i, j = pos
            return self.map[i][j] in (FREE_SPACE_VALUE, FRONTIER_VALUE)

        def heuristic(a, b):
            return abs(a[0] - b[0]) + abs(a[1] - b[1])  # Manhattan distance

        open_list = []  # Each element is (f_cost, g_cost, node, parent)
        closed_list = set()
        open_dict = {}  # For quick lookup and updates

        # Initialize
        g_start = 0
        f_start = heuristic(start, goal)
        open_list.append((f_start, g_start, start, None))
        open_dict[start] = (f_start, g_start, None)

        while open_list:
            # Sort to get node with lowest f at front
            open_list.sort(key=lambda x: x[0])
            f, g, current, parent = open_list.pop(0)
            open_dict.pop(current)
            closed_list.add(current)

            if current == goal:
                # Reconstruct path
                path = [current]
                while parent:
                    path.append(parent)
                    parent = open_dict.get(parent, (None, None, None))[2]
                return path[::-1]

            for d in DIRECTIONS:
                neighbor = (current[0] + d[0], current[1] + d[1])
                if not in_bounds(neighbor) or not is_walkable(neighbor):
                    continue
                if neighbor in closed_list:
                    continue

                g_neighbor = g + 1
                f_neighbor = g_neighbor + heuristic(neighbor, goal)

                if neighbor not in open_dict or g_neighbor < open_dict[neighbor][1]:
                    open_list.append((f_neighbor, g_neighbor, neighbor, current))
                    open_dict[neighbor] = (f_neighbor, g_neighbor, current)

        # No path found
        return [goal]

    def calculate_path_cost(self, path: list, safety_distance=2) -> float:
        """Calculate path cost considering other robots' positions."""
        if not path:
            return float('inf')
            
        cost = len(path)
        
        # Add cost for paths that come close to other robots
        for point in path:
            for robot_pos in self.agents_pose_grid:
                distance = abs(point[0] - robot_pos[0]) + abs(point[1] - robot_pos[1])
                if distance < safety_distance:
                    cost += (safety_distance - distance) * 3  # Increased penalty for proximity
                    
        return cost

    def follow_path(self) -> None:
        """
        Dynamically update destination cell to follow the planned path.
        Sets self.dest_row and self.dest_col to the next step in the path.
        """
        try:
            if not self.path:
                return  # No path to follow

            # Check if we've reached (or are close to) the next target cell
            if abs(self.row - self.path[0][0]) + abs(self.col - self.path[0][1]) < 3:
                self.path.pop(0)

            if self.path:
                self.dest_row, self.dest_col = self.path[0][0], self.path[0][1]

        except Exception as e:
            self.get_logger().warn(f"Exception in follow_path: {e}")
            return

    def strategy(self) -> None:
        """ Decision and action layers """
        try:
            # Do not touch (update current gridmap position data)
            self.row, self.col = self.coordinates_to_grid(self.x, self.y)
            
            # ======================== UPDATE THIS SECTION ========================
            # Compute frontier cells
            frontiers = self.get_frontier_cells()
            
            # Update regions
            self.regions = self.get_regions(frontiers)

            # Select the best region to go to
            self.avg_reg_utilities = []

            for region in self.regions:
                total_util = sum(self.calculate_utility(cell) for cell in region)
                avg_util = total_util / len(region)
                self.avg_reg_utilities.append((region, avg_util))

            # Sort regions by descending average utility
            self.avg_reg_utilities.sort(key=lambda x: x[1], reverse=True)

            # Set the region with highest utility as destination
            fallback_region = self.avg_reg_utilities[0][0].copy()
            selected_region = None
            for region, _ in self.avg_reg_utilities:
                conflict = False
                for other_id, other_region in Agent.dest_regions.items():
                    if other_id != self.id and other_region == region:
                        conflict = True
                        break
                if not conflict:
                    selected_region = region.copy()
                    break

            # If no non-conflicting region was found, use the best one anyway
            if selected_region is None:
                selected_region = fallback_region

            Agent.dest_regions[self.id] = selected_region

            # Compute the center of gravity of the destination region
            Agent.dest_cells[self.id] = self.center_of_gravity(Agent.dest_regions[self.id])

            # Find a path to the CoG using A* algorithm
            self.path = self.astar((self.row, self.col), Agent.dest_cells[self.id])
            self.get_logger().info(f"Path: {self.path}")
            # =====================================================================

            # Do not touch (movement)
            self.follow_path()
            self.move_to_dest()

            # Publish command
            self.cmd_vel_pub.publish(self.cmd_vel)
            pass
        except Exception as e:
            self.get_logger().warn(f"Exception in strategy: {e}")
            return None

def main():
    rclpy.init()

    node = Agent()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    while True:
        rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()