# Intelligent distributed systems project
Implementation of an algorithm on ROS to make 3 robots equipped with a lidar navigate through a labyrinth


## Commands
ros2 launch in424_simu start_world_launch.py
ros2 launch in424_nav agents_launch.py
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros_args -r cmd_vel:=bot_1/cmd_vel
